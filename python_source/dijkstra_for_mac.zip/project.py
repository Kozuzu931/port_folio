#
# 対象プロジェクトの設定
#

project = 'ikebukuro'
#project = 'akabane'
